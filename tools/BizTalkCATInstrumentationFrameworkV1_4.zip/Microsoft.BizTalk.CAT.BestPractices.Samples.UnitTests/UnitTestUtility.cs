﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace Microsoft.BizTalk.CAT.BestPractices.UnitTests
{
    public static class UnitTestUtility
    {
        /// <summary>
        /// The name of the folder that contains all test results.
        /// </summary>
        public const string TestResultsFolderName = "TestResults";

        /// <summary>
        /// The name of the folder that contains all tracing tools.
        /// </summary>
        public const string TracingToolsFolderName = "TracingTools";

        /// <summary>
        /// The name of the folder that contains all test messages.
        /// </summary>
        public const string TestMessageFolderName = "TestMessages";

        /// <summary>
        /// The regular expression that helps to determine the root location of the project.
        /// </summary>
        private static string testRootExtractionRegex = @"^(?<solroot>.*)" + TestResultsFolderName + "\\\\";

        /// <summary>
        /// Returns a full path to the folder in which the TestResults folder was created by Visual Studio.
        /// </summary>
        /// <param name="testDir">A result from TestContext.TestDir</param>
        /// <returns>The full path to the folder containing the TestResults folder.</returns>
        public static string GetTestRoot(string testDir)
        {
            Regex extrationEx = new Regex(testRootExtractionRegex, RegexOptions.IgnoreCase | RegexOptions.Singleline);
            Match pathMatch = extrationEx.Match(testDir);

            if (pathMatch.Success)
            {
                return pathMatch.Groups["solroot"].Value;
            }
            else
            {
                return testDir;
            }
        }
    }
}
