﻿using System;
using System.Text;
using System.IO;
using System.Diagnostics;
using System.Threading;

using Microsoft.BizTalk.Tracing;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.BizTalk.CAT.BestPractices.Framework;
using Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation;
using Microsoft.BizTalk.CAT.BestPractices.Tests.Properties;

using EtwTraceLevel = Microsoft.BizTalk.Tracing.TraceLevel;
using SystemTrace = System.Diagnostics.Trace;

namespace Microsoft.BizTalk.CAT.BestPractices.UnitTests
{
    /// <summary>
    /// Unit test implementations covering the TraceManager component.
    /// </summary>
    [TestClass]
    public class TraceManagerUnitTests
    {
        private static string testRootFolder;
        private static string tracingToolsFolder;
        private TestContext testContextInstance;

        private const string PipelineComponent = "Pipeline";
        private const string WorkflowComponent = "Workflow";
        private const string DataAccessComponent = "DataAccess";
        private const string TransformComponent = "Transform";
        private const string ServiceComponent = "Service";
        private const string RulesComponent = "Rules";
        private const string CustomComponent = "Custom";

        private const string StartTraceScript = "StartTrace.cmd";
        private const string StartTraceCmdLine = "-log {0} -level {1} -component {2}";
        private const string StopTraceScript = "StopTrace.cmd";
        private const string StopTraceCmdLine = "-log {0}";

        public TraceManagerUnitTests()
        {
        }

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        [ClassInitialize()]
        public static void TraceManagerUnitTestsInit(TestContext testContext)
        {
            testRootFolder = UnitTestUtility.GetTestRoot(testContext.TestLogsDir);
            tracingToolsFolder = Path.Combine(testRootFolder, UnitTestUtility.TracingToolsFolderName);
        }
        #endregion

        #region PipelineComponentTracing tests
        [TestMethod]
        public void TestPipelineComponentTracing_TraceLevelAll()
        {
            TestComponentLevelTracing(TraceManager.PipelineComponent, PipelineComponent, TraceLevelMapping.All);
        }

        [TestMethod]
        public void TestPipelineComponentTracing_TraceLevelHigh()
        {
            TestComponentLevelTracing(TraceManager.PipelineComponent, PipelineComponent, TraceLevelMapping.High);
        }

        [TestMethod]
        public void TestPipelineComponentTracing_TraceLevelMedium()
        {
            TestComponentLevelTracing(TraceManager.PipelineComponent, PipelineComponent, TraceLevelMapping.Medium);
        }

        [TestMethod]
        public void TestPipelineComponentTracing_TraceLevelLow()
        {
            TestComponentLevelTracing(TraceManager.PipelineComponent, PipelineComponent, TraceLevelMapping.Low);
        }

        [TestMethod]
        public void TestPipelineComponentTracing_TraceLevelNone()
        {
            TestComponentLevelTracing(TraceManager.PipelineComponent, PipelineComponent, TraceLevelMapping.None);
        } 
        #endregion

        #region WorkflowComponentTracing tests
        [TestMethod]
        public void TestWorkflowComponentTracing_TraceLevelAll()
        {
            TestComponentLevelTracing(TraceManager.WorkflowComponent, WorkflowComponent, TraceLevelMapping.All);
        }

        [TestMethod]
        public void TestWorkflowComponentTracing_TraceLevelHigh()
        {
            TestComponentLevelTracing(TraceManager.WorkflowComponent, WorkflowComponent, TraceLevelMapping.High);
        }

        [TestMethod]
        public void TestWorkflowComponentTracing_TraceLevelMedium()
        {
            TestComponentLevelTracing(TraceManager.WorkflowComponent, WorkflowComponent, TraceLevelMapping.Medium);
        }

        [TestMethod]
        public void TestWorkflowComponentTracing_TraceLevelLow()
        {
            TestComponentLevelTracing(TraceManager.WorkflowComponent, WorkflowComponent, TraceLevelMapping.Low);
        }

        [TestMethod]
        public void TestWorkflowComponentTracing_TraceLevelNone()
        {
            TestComponentLevelTracing(TraceManager.WorkflowComponent, WorkflowComponent, TraceLevelMapping.None);
        }
        #endregion

        #region DataAccessComponentTracing tests
        [TestMethod]
        public void TestDataAccessComponentTracing_TraceLevelAll()
        {
            TestComponentLevelTracing(TraceManager.DataAccessComponent, DataAccessComponent, TraceLevelMapping.All);
        }

        [TestMethod]
        public void TestDataAccessComponentTracing_TraceLevelHigh()
        {
            TestComponentLevelTracing(TraceManager.DataAccessComponent, DataAccessComponent, TraceLevelMapping.High);
        }

        [TestMethod]
        public void TestDataAccessComponentTracing_TraceLevelMedium()
        {
            TestComponentLevelTracing(TraceManager.DataAccessComponent, DataAccessComponent, TraceLevelMapping.Medium);
        }

        [TestMethod]
        public void TestDataAccessComponentTracing_TraceLevelLow()
        {
            TestComponentLevelTracing(TraceManager.DataAccessComponent, DataAccessComponent, TraceLevelMapping.Low);
        }

        [TestMethod]
        public void TestDataAccessComponentTracing_TraceLevelNone()
        {
            TestComponentLevelTracing(TraceManager.DataAccessComponent, DataAccessComponent, TraceLevelMapping.None);
        }
        #endregion

        #region TransformComponentTracing tests
        [TestMethod]
        public void TestTransformComponentTracing_TraceLevelAll()
        {
            TestComponentLevelTracing(TraceManager.TransformComponent, TransformComponent, TraceLevelMapping.All);
        }

        [TestMethod]
        public void TestTransformComponentTracing_TraceLevelHigh()
        {
            TestComponentLevelTracing(TraceManager.TransformComponent, TransformComponent, TraceLevelMapping.High);
        }

        [TestMethod]
        public void TestTransformComponentTracing_TraceLevelMedium()
        {
            TestComponentLevelTracing(TraceManager.TransformComponent, TransformComponent, TraceLevelMapping.Medium);
        }

        [TestMethod]
        public void TestTransformComponentTracing_TraceLevelLow()
        {
            TestComponentLevelTracing(TraceManager.TransformComponent, TransformComponent, TraceLevelMapping.Low);
        }

        [TestMethod]
        public void TestTransformComponentTracing_TraceLevelNone()
        {
            TestComponentLevelTracing(TraceManager.TransformComponent, TransformComponent, TraceLevelMapping.None);
        }
        #endregion

        #region ServiceComponentTracing tests
        [TestMethod]
        public void TestServiceComponentTracing_TraceLevelAll()
        {
            TestComponentLevelTracing(TraceManager.ServiceComponent, ServiceComponent, TraceLevelMapping.All);
        }

        [TestMethod]
        public void TestServiceComponentTracing_TraceLevelHigh()
        {
            TestComponentLevelTracing(TraceManager.ServiceComponent, ServiceComponent, TraceLevelMapping.High);
        }

        [TestMethod]
        public void TestServiceComponentTracing_TraceLevelMedium()
        {
            TestComponentLevelTracing(TraceManager.ServiceComponent, ServiceComponent, TraceLevelMapping.Medium);
        }

        [TestMethod]
        public void TestServiceComponentTracing_TraceLevelLow()
        {
            TestComponentLevelTracing(TraceManager.ServiceComponent, ServiceComponent, TraceLevelMapping.Low);
        }

        [TestMethod]
        public void TestServiceComponentTracing_TraceLevelNone()
        {
            TestComponentLevelTracing(TraceManager.ServiceComponent, ServiceComponent, TraceLevelMapping.None);
        }
        #endregion

        #region RulesComponentTracing tests
        [TestMethod]
        public void TestRulesComponentTracing_TraceLevelAll()
        {
            TestComponentLevelTracing(TraceManager.RulesComponent, RulesComponent, TraceLevelMapping.All);
        }

        [TestMethod]
        public void TestRulesComponentTracing_TraceLevelHigh()
        {
            TestComponentLevelTracing(TraceManager.RulesComponent, RulesComponent, TraceLevelMapping.High);
        }

        [TestMethod]
        public void TestRulesComponentTracing_TraceLevelMedium()
        {
            TestComponentLevelTracing(TraceManager.RulesComponent, RulesComponent, TraceLevelMapping.Medium);
        }

        [TestMethod]
        public void TestRulesComponentTracing_TraceLevelLow()
        {
            TestComponentLevelTracing(TraceManager.RulesComponent, RulesComponent, TraceLevelMapping.Low);
        }

        [TestMethod]
        public void TestRulesComponentTracing_TraceLevelNone()
        {
            TestComponentLevelTracing(TraceManager.RulesComponent, RulesComponent, TraceLevelMapping.None);
        }
        #endregion

        #region CustomComponentTracing tests
        [TestMethod]
        public void TestCustomComponentTracing_TraceLevelAll()
        {
            TestComponentLevelTracing(TraceManager.CustomComponent, CustomComponent, TraceLevelMapping.All);
        }

        [TestMethod]
        public void TestCustomComponentTracing_TraceLevelHigh()
        {
            TestComponentLevelTracing(TraceManager.CustomComponent, CustomComponent, TraceLevelMapping.High);
        }

        [TestMethod]
        public void TestCustomComponentTracing_TraceLevelMedium()
        {
            TestComponentLevelTracing(TraceManager.CustomComponent, CustomComponent, TraceLevelMapping.Medium);
        }

        [TestMethod]
        public void TestCustomComponentTracing_TraceLevelLow()
        {
            TestComponentLevelTracing(TraceManager.CustomComponent, CustomComponent, TraceLevelMapping.Low);
        }

        [TestMethod]
        public void TestCustomComponentTracing_TraceLevelNone()
        {
            TestComponentLevelTracing(TraceManager.CustomComponent, CustomComponent, TraceLevelMapping.None);
        }
        #endregion

        #region Other test methods
        [TestMethod]
        public void TestTraceInWithExpensiveDataProvider()
        {
            int sleepTime = 1000;

            Func<string> expensiveMethod = () =>
            {
                Thread.Sleep(sleepTime);

                return String.Format("I was sleeping for {0}ms", sleepTime);
            };

            Stopwatch stopwatch = Stopwatch.StartNew();

            // Write to a trace log when ETW tracing is disabled.
            TraceManager.CustomComponent.TraceInfo(expensiveMethod);

            stopwatch.Stop();

#if DEBUG
            Assert.IsTrue(stopwatch.ElapsedMilliseconds >= sleepTime, String.Format("Unexpected duration of {0}", stopwatch.ElapsedMilliseconds));
#else
            Assert.IsTrue(stopwatch.ElapsedMilliseconds < sleepTime, String.Format("Unexpected duration of {0}", stopwatch.ElapsedMilliseconds));

            string traceLogName = StartTrace(CustomComponent, TraceLevelMapping.All);

            try
            {
                stopwatch.Start();

                // Write to a trace log when ETW tracing is enabled.
                TraceManager.CustomComponent.TraceInfo(expensiveMethod);

                stopwatch.Stop();

                Assert.IsTrue(stopwatch.ElapsedMilliseconds >= sleepTime, String.Format("Unexpected duration of {0}", stopwatch.ElapsedMilliseconds));
            }
            finally
            {
                string formattedTraceLog = StopTrace(traceLogName);

                if (File.Exists(formattedTraceLog))
                {
                    File.Delete(formattedTraceLog);
                }

                SystemTrace.WriteLine(String.Format("Formatted Trace Log = {0}", formattedTraceLog));
            }
#endif
        }
        #endregion

        #region Private methods
        private void TestComponentLevelTracing(IComponentTraceProvider traceProvider, string component, uint traceLevel)
        {
            string traceLogName = StartTrace(component, traceLevel);

            try
            {
                var callToken = traceProvider.TraceIn(Resources.MagicWordTraceInEvent);
                traceProvider.TraceInfo(Resources.MagicWordInfoEvent);

                try
                {
                    traceProvider.TraceWarning(Resources.MagicWordWarningEvent);

                    var scopeStarted = traceProvider.TraceStartScope(Resources.MagicWordTraceStartScopeEvent, callToken);

                    Thread.Sleep((new Random(DateTime.Now.Millisecond)).Next(0, 200));

                    traceProvider.TraceEndScope(Resources.MagicWordTraceEndScopeEvent, scopeStarted, callToken);

                    throw new DivideByZeroException();
                }
                catch
                {
                    traceProvider.TraceError(Resources.MagicWordErrorEvent);
                }

                traceProvider.TraceOut(callToken, Resources.MagicWordTraceOutEvent);
            }
            finally
            {
                string formattedTraceLog = StopTrace(traceLogName);
                AnalyzeFormattedTraceLog(formattedTraceLog, traceLevel);
            }
        }

        private void AnalyzeFormattedTraceLog(string formattedTraceLog, uint traceLevel)
        {
            int errorsLogged = 0, warningsLogged = 0, infoEventsLogged = 0, traceInEventsLogged = 0, traceOutEventsLogged = 0;
            int traceStartScopeEventsLogged = 0, traceEndScopeEventsLogged = 0;

            using (StreamReader textFileReader = File.OpenText(formattedTraceLog))
            {
                while (!textFileReader.EndOfStream)
                {
                    string lineOfText = textFileReader.ReadLine();

                    if (lineOfText.Contains(Resources.MagicWordTraceInEvent))
                    {
                        if ((traceLevel & EtwTraceLevel.Tracking) == 0)
                        {
                            throw new InvalidDataException(String.Format("Unexpected event was found for \"{0}\" trace level: {1}", traceLevel, lineOfText));
                        }
                        traceInEventsLogged++;
                    }

                    if (lineOfText.Contains(Resources.MagicWordTraceOutEvent))
                    {
                        if ((traceLevel & EtwTraceLevel.Tracking) == 0)
                        {
                            throw new InvalidDataException(String.Format("Unexpected event was found for \"{0}\" trace level: {1}", traceLevel, lineOfText));
                        }
                        traceOutEventsLogged++;
                    }

                    if (lineOfText.Contains(Resources.MagicWordTraceStartScopeEvent))
                    {
                        if ((traceLevel & EtwTraceLevel.Tracking) == 0)
                        {
                            throw new InvalidDataException(String.Format("Unexpected event was found for \"{0}\" trace level: {1}", traceLevel, lineOfText));
                        }
                        traceStartScopeEventsLogged++;
                    }

                    if (lineOfText.Contains(Resources.MagicWordTraceEndScopeEvent))
                    {
                        if ((traceLevel & EtwTraceLevel.Tracking) == 0)
                        {
                            throw new InvalidDataException(String.Format("Unexpected event was found for \"{0}\" trace level: {1}", traceLevel, lineOfText));
                        }
                        traceEndScopeEventsLogged++;
                    }

                    if (lineOfText.Contains(Resources.MagicWordInfoEvent))
                    {
                        if((traceLevel & EtwTraceLevel.Info) == 0)
                        {
                            throw new InvalidDataException(String.Format("Unexpected event was found for \"{0}\" trace level: {1}", traceLevel, lineOfText));
                        }
                        infoEventsLogged++;
                    }

                    if (lineOfText.Contains(Resources.MagicWordWarningEvent))
                    {
                        if ((traceLevel & EtwTraceLevel.Warning) == 0)
                        {
                            throw new InvalidDataException(String.Format("Unexpected event was found for \"{0}\" trace level: {1}", traceLevel, lineOfText));
                        }
                        warningsLogged++;
                    }

                    if (lineOfText.Contains(Resources.MagicWordErrorEvent))
                    {
                        if ((traceLevel & EtwTraceLevel.Error) == 0)
                        {
                            throw new InvalidDataException(String.Format("Unexpected event was found for \"{0}\" trace level: {1}", traceLevel, lineOfText));
                        }
                        errorsLogged++;
                    }
                }
            }

            if ((traceLevel & EtwTraceLevel.Tracking) != 0 && traceInEventsLogged == 0)
            {
                throw new InvalidDataException(String.Format("TraceIn events were expected for trace level of {0} but none were found", TraceLevelMapping.GetTraceLevelName(traceLevel)));
            }

            if ((traceLevel & EtwTraceLevel.Tracking) != 0 && traceOutEventsLogged == 0)
            {
                throw new InvalidDataException(String.Format("TraceOut events were expected for trace level of {0} but none were found", TraceLevelMapping.GetTraceLevelName(traceLevel)));
            }

            if ((traceLevel & EtwTraceLevel.Tracking) != 0 && traceStartScopeEventsLogged == 0)
            {
                throw new InvalidDataException(String.Format("TraceStartScope events were expected for trace level of {0} but none were found", TraceLevelMapping.GetTraceLevelName(traceLevel)));
            }

            if ((traceLevel & EtwTraceLevel.Tracking) != 0 && traceEndScopeEventsLogged == 0)
            {
                throw new InvalidDataException(String.Format("TraceEndScope events were expected for trace level of {0} but none were found", TraceLevelMapping.GetTraceLevelName(traceLevel)));
            }

            if ((traceLevel & EtwTraceLevel.Info) != 0 && infoEventsLogged == 0)
            {
                throw new InvalidDataException(String.Format("Informational events were expected for trace level of {0} but none were found", TraceLevelMapping.GetTraceLevelName(traceLevel)));
            }

            if ((traceLevel & EtwTraceLevel.Warning) != 0 && warningsLogged == 0)
            {
                throw new InvalidDataException(String.Format("Warnings were expected for trace level of {0} but none were found", TraceLevelMapping.GetTraceLevelName(traceLevel)));
            }

            if ((traceLevel & EtwTraceLevel.Error) != 0 && errorsLogged == 0)
            {
                throw new InvalidDataException(String.Format("Errors were expected for trace level of {0} but none were found", TraceLevelMapping.GetTraceLevelName(traceLevel)));
            }

            File.Delete(formattedTraceLog);
        }

        private static DateTime MySampleMethod(int counter, DateTime dateNow)
        {
            TraceManager.CustomComponent.TraceIn(counter, dateNow);

            DateTime newDate = dateNow.AddYears(counter);

            TraceManager.CustomComponent.TraceOut(newDate);
            return newDate;
        }

        private string StartTrace(string component, uint traceLevel)
        {
            string traceLogName = Path.Combine(testRootFolder, Path.GetRandomFileName());
            string execFileName = Path.Combine(tracingToolsFolder, StartTraceScript);

            ProcessStartInfo processStartInfo = new ProcessStartInfo();
            processStartInfo.Arguments = String.Format(StartTraceCmdLine, traceLogName, TraceLevelMapping.GetTraceLevelName(traceLevel), component);
            processStartInfo.ErrorDialog = true;
            processStartInfo.FileName = execFileName;
            processStartInfo.UseShellExecute = true;
            processStartInfo.WindowStyle = ProcessWindowStyle.Normal;
            processStartInfo.WorkingDirectory = tracingToolsFolder;

            Process externalProcess = new Process();
            externalProcess.StartInfo = processStartInfo;
            externalProcess.Start();
            externalProcess.WaitForExit();

            Thread.Sleep(1000);

            return traceLogName;
        }

        private string StopTrace(string traceLogName)
        {
            ProcessStartInfo processStartInfo = new ProcessStartInfo();
            processStartInfo.Arguments = String.Format(StopTraceCmdLine, traceLogName);
            processStartInfo.ErrorDialog = true;
            processStartInfo.FileName = Path.Combine(tracingToolsFolder, StopTraceScript);
            processStartInfo.UseShellExecute = true;
            processStartInfo.WindowStyle = ProcessWindowStyle.Normal;
            processStartInfo.WorkingDirectory = tracingToolsFolder;

            Process externalProcess = new Process();
            externalProcess.StartInfo = processStartInfo;
            externalProcess.Start();
            externalProcess.WaitForExit();

            string formattedTraceLog = traceLogName + ".txt";
            string formattingSummaryLog = formattedTraceLog + ".sum";

            if (File.Exists(traceLogName))
            {
                File.Delete(traceLogName);
            }
            else
            {
                throw new ApplicationException(String.Format("There appears to have been an error while capturing the trace log file. Unable to locate log file: {0}", traceLogName));
            }

            if (File.Exists(formattingSummaryLog))
            {
                File.Delete(formattingSummaryLog);
            }

            if (!File.Exists(formattedTraceLog))
            {
                throw new ApplicationException(String.Format("There appears to have been an error while converting the log file into readable format. Unable to locate log file: {0}", formattedTraceLog));
            }

            return formattedTraceLog;
        }
        #endregion
    }
}

