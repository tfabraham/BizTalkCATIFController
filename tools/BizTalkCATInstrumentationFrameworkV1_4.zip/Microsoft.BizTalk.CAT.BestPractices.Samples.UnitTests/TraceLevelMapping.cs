﻿using System;
using Microsoft.BizTalk.Tracing;

namespace Microsoft.BizTalk.CAT.BestPractices.UnitTests
{
    public static class TraceLevelMapping
    {
        public const uint None = 0;
        public const uint Low = TraceLevel.Error;
        public const uint Medium = TraceLevel.Error | TraceLevel.Warning;
        public const uint High = TraceLevel.Error | TraceLevel.Warning | TraceLevel.Info;
        public const uint All = TraceLevel.Context | TraceLevel.Error | TraceLevel.Info | TraceLevel.Locks | TraceLevel.Messages | TraceLevel.SegmentLifeTime | TraceLevel.ServiceLifetime | TraceLevel.Store | TraceLevel.Tracking | TraceLevel.Warning;

        public static string GetTraceLevelName(uint traceLevel)
        {
            switch (traceLevel)
            {
                case TraceLevelMapping.None: return "none";
                case TraceLevelMapping.Low: return "low";
                case TraceLevelMapping.Medium: return "medium";
                case TraceLevelMapping.High: return "high";
                case TraceLevelMapping.All: return "all";

                default: return "none";
            }
        }
    }
}
