﻿using System;
using System.Diagnostics;
using System.IO;
using System.Text;

using EtwTraceManager = Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.TraceManager;
using CustomExceptionFormatter = Microsoft.BizTalk.CAT.BestPractices.Framework.Instrumentation.ExceptionFormatter;

using Microsoft.Practices.EnterpriseLibrary.Logging;

using log4net;
using log4net.Core;
using log4net.Config;

namespace Microsoft.BizTalk.CAT.BestPractices.Samples.TracingBenchmark
{
    class Program
    {
        private const int MaxNumberOfTraceEvents = 1;
        private const int DefaultNumberOfTestRuns = 1;
        private const string SampleTraceEventText = "This is a sample trace event (iteration = {0})";
        private const string TestResultFileName = "TracingBenchmarkResults.csv";
        private const string TestResultFileHeader = "TestName,TestDateTime,EventCount,Duration,EventsPerSec";
        private static readonly ILog log4netLogger = LogManager.GetLogger(typeof(Program));

        static void Main(string[] args)
        {
            try
            {
                int numberOfTestRuns = DefaultNumberOfTestRuns;
                int numberOfEvents = MaxNumberOfTraceEvents;
                string testCaseList = String.Empty;

                if (args != null && args.Length > 0)
                {
                    for (int i = 0; i < args.Length; i++)
                    {
                        if (args[i] == "/t" && (i + 1) < args.Length)
                        {
                            numberOfTestRuns = Convert.ToInt32(args[i + 1]);
                            i++;
                        }

                        if (args[i] == "/e" && (i + 1) < args.Length)
                        {
                            numberOfEvents = Convert.ToInt32(args[i + 1]);
                            i++;
                        }
                        
                        if (args[i] == "/c" && (i + 1) < args.Length)
                        {
                            testCaseList = args[i + 1];
                            i++;
                        }
                    }
                }

                Console.Clear();
                Console.WriteLine("Tracing Component Benchmark Utility");
                Console.WriteLine("Test Configuration: number of test runs = {0}, number of events = {1}", numberOfTestRuns, numberOfEvents);

                log4net.Config.XmlConfigurator.Configure(); 

                if (!File.Exists(TestResultFileName))
                {
                    File.WriteAllLines(TestResultFileName, new string[]{ TestResultFileHeader }, Encoding.ASCII);
                }

                using (FileStream resultsFile = new FileStream(TestResultFileName, FileMode.Append, FileAccess.Write, FileShare.None))
                {
                    StreamWriter resultsWriter = new StreamWriter(resultsFile, Encoding.ASCII, 4096);

                    WarmUp();

                    for (int i = 0; i < numberOfTestRuns; i++)
                    {
                        ConsoleColor oldColor = Console.ForegroundColor;
                        Console.ForegroundColor = ConsoleColor.Green;

                        Console.WriteLine("\nExecuting Test #{0}...", i + 1);

                        Console.ForegroundColor = oldColor;

                        if (String.IsNullOrEmpty(testCaseList) || testCaseList.Contains("etw"))
                        {
                            TimeSpan etwComponentTestDuration = BenchmarkEtwTracingComponent(numberOfEvents);
                            WriteTestResults(resultsWriter, "ETW Tracing Component", numberOfEvents, etwComponentTestDuration);
                        }

                        if (String.IsNullOrEmpty(testCaseList) || testCaseList.Contains("trace"))
                        {
                            TimeSpan systemTraceComponentTestDuration = BenchmarkSystemDiagnosticsTrace(numberOfEvents);
                            WriteTestResults(resultsWriter, "System.Diagnostics.Trace Component", numberOfEvents, systemTraceComponentTestDuration);
                        }

                        if (String.IsNullOrEmpty(testCaseList) || testCaseList.Contains("log4net"))
                        {
                            TimeSpan log4NetComponentTestDuration = BenchmarkLog4NetTracingComponent(numberOfEvents);
                            WriteTestResults(resultsWriter, "Log4Net Tracing Component", numberOfEvents, log4NetComponentTestDuration);
                        }

                        if (String.IsNullOrEmpty(testCaseList) || testCaseList.Contains("entlib5"))
                        {
                            TimeSpan entLibComponentTestDuration = BenchmarkEntLibTracingComponent(numberOfEvents);
                            WriteTestResults(resultsWriter, "EntLib5 Tracing Component", numberOfEvents, entLibComponentTestDuration);
                        }
                    }

                    resultsWriter.Flush();
                    TraceLogFlush();
                }

                Console.WriteLine();
                Console.WriteLine("All tests are completed.");
            }
            catch (Exception ex)
            {
                HandleConsoleAppException(ex);
            }
        }

        #region Benchmarking methods
        private static TimeSpan BenchmarkEtwTracingComponent(int maxEvents)
        {
            Stopwatch stopwatch = Stopwatch.StartNew();

            for (int i = 0; i < maxEvents; i++)
            {
                EtwTraceManager.CustomComponent.TraceInfo(SampleTraceEventText, i);
            }

            stopwatch.Stop();
            return stopwatch.Elapsed;
        }

        private static TimeSpan BenchmarkSystemDiagnosticsTrace(int maxEvents)
        {
            Stopwatch stopwatch = Stopwatch.StartNew();

            for (int i = 0; i < maxEvents; i++)
            {
                Trace.Write(String.Format(SampleTraceEventText, i));
            }

            stopwatch.Stop();
            return stopwatch.Elapsed;
        }

        private static TimeSpan BenchmarkLog4NetTracingComponent(int maxEvents)
        {
            Stopwatch stopwatch = Stopwatch.StartNew();

            for (int i = 0; i < maxEvents; i++)
            {
                TraceUsingLog4Net(SampleTraceEventText, i);
            }

            stopwatch.Stop();
            return stopwatch.Elapsed;
        }

        private static TimeSpan BenchmarkEntLibTracingComponent(int maxEvents)
        {
            Stopwatch stopwatch = Stopwatch.StartNew();

            for (int i = 0; i < maxEvents; i++)
            {
                TraceUsingEntLib(SampleTraceEventText, i);
            }

            stopwatch.Stop();
            return stopwatch.Elapsed;
        }
        #endregion

        #region Log4Net helper methods
        private static void TraceUsingLog4Net(string format, params object[] parameters)
        {
            WriteLog(Level.Trace, String.Format(format, parameters));
        }

        private static void WriteLog(Level level, string message)
        {
            LoggingEvent logEvent = new LoggingEvent(typeof(Program), log4netLogger.Logger.Repository, log4netLogger.Logger.Name, level, message, null);
            log4netLogger.Logger.Log(logEvent);
        }
        #endregion

        #region Enterprise Library helper methods
        private static LogWriter entLibTraceWriter;

        private static LogWriter EntLibTraceWriter
        {
            get
            {
                if (null == entLibTraceWriter)
                {
                    LogWriterFactory factory = new LogWriterFactory();
                    entLibTraceWriter = factory.Create();
                }

                return entLibTraceWriter;
            }
        }

        private static void TraceUsingEntLib(string format, params object[] parameters)
        {
            LogEntry logEntry = new LogEntry();
            logEntry.Categories.Add("General");
            logEntry.Message = String.Format(format, parameters);

            EntLibTraceWriter.Write(logEntry);
        }
        #endregion

        #region Other helper methods
        private static void WarmUp()
        {
            EtwTraceManager.CustomComponent.TraceInfo("This is warm-up event written into ETW trace log - please ignore");
            Trace.Write("This is warm-up event written into System.Diagnostics.Trace listener - please ignore");
            TraceUsingLog4Net("This is warm-up event written using Log4Net library - please ignore");
            TraceUsingEntLib("This is warm-up event written using EntLib logging application block - please ignore");
        }

        private static void TraceLogFlush()
        {
            Trace.Flush();
        }

        private static void WriteTestResults(StreamWriter resultsWriter, string testName, int eventCount, TimeSpan duration)
        {
            Console.WriteLine();
            Console.WriteLine("Test results for {0}", testName);

            ConsoleColor oldColor = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.Yellow;

            double durationInSeconds = duration.TotalSeconds;
            double eventsPerSec = eventCount / durationInSeconds;

            Console.WriteLine("\tTotal trace events = {0}", eventCount);
            Console.WriteLine("\tTotal seconds = {0}", durationInSeconds);
            Console.WriteLine("\tTrace events per sec = {0}", eventsPerSec);
            
            Console.ForegroundColor = oldColor;

            resultsWriter.WriteLine(String.Format("{0},{1},{2},{3},{4}", testName, DateTime.Now.ToString(), eventCount, durationInSeconds, eventsPerSec));
        }

        private static void HandleConsoleAppException(Exception ex)
        {
            CustomExceptionFormatter exceptionFormatter = new CustomExceptionFormatter();

            ConsoleColor oldColor = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.Red;

            Console.WriteLine("EXCEPTION: {0}", exceptionFormatter.FormatException(ex));

            Console.ForegroundColor = oldColor;
        }
        #endregion
    }
}
